interface User{
    id:number;
    account:string
}

export default User;