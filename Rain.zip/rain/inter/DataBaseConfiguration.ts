interface DataBaseConfiguration {
    init:(...arg:any) => void;
}

export default DataBaseConfiguration;