import Application from "./rain/index.ts"

const application = new Application();