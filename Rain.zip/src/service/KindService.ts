import { Service } from '../../rain/index.ts'
@Service
class KindService {
    
    public getKind(){
        return "KindService"
    }
}

export default KindService;